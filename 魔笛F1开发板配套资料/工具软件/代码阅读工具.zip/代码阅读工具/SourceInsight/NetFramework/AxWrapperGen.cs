namespace System.Windows.Forms.Design {
public class AxWrapperGen
{

	// Constructors
	public AxWrapperGen(Type axType) {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public System.Collections.ArrayList GeneratedSources;
}

}
