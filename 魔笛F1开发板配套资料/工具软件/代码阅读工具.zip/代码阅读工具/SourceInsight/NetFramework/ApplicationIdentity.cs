namespace System {
public class ApplicationIdentity : System.Runtime.Serialization.ISerializable
{

	// Constructors
	public ApplicationIdentity(string applicationIdentityFullName) {}

	// Methods
	public virtual string ToString() {}
	public Type GetType() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public string FullName { get{} }
	public string CodeBase { get{} }
}

}
