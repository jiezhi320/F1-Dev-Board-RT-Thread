namespace System.Web.Hosting {
public class AppDomainInfoEnum : IAppDomainInfoEnum
{

	// Methods
	public virtual int Count() {}
	public virtual IAppDomainInfo GetData() {}
	public virtual bool MoveNext() {}
	public virtual void Reset() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
