namespace Microsoft.JScript {
public class ArrayLiteral : AST
{

	// Constructors
	public ArrayLiteral(Context context, ASTList elements) {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
