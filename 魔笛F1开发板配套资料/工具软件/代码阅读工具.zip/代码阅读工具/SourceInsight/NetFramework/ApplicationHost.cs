namespace System.Web.Hosting {
public class ApplicationHost
{

	// Methods
	public static object CreateApplicationHost(Type hostType, string virtualDir, string physicalDir) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
