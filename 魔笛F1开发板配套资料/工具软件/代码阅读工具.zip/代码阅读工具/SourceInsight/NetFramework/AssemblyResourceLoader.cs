namespace System.Web.Handlers {
public class AssemblyResourceLoader : System.Web.IHttpHandler
{

	// Constructors
	public AssemblyResourceLoader() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
