namespace System.Xml.Xsl.Runtime {
public class AttributeIterator : System.ValueType
{

	// Methods
	public void Create(System.Xml.XPath.XPathNavigator context) {}
	public bool MoveNext() {}
	public virtual int GetHashCode() {}
	public virtual bool Equals(object obj) {}
	public virtual string ToString() {}
	public Type GetType() {}

	// Properties
	public System.Xml.XPath.XPathNavigator Current { get{} }
}

}
