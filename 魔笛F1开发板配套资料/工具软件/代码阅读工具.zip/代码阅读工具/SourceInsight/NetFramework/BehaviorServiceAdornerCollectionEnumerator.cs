namespace System.Windows.Forms.Design.Behavior {
public class BehaviorServiceAdornerCollectionEnumerator : System.Collections.IEnumerator
{

	// Constructors
	public BehaviorServiceAdornerCollectionEnumerator(BehaviorServiceAdornerCollection mappings) {}

	// Methods
	public bool MoveNext() {}
	public void Reset() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public Adorner Current { get{} }
}

}
