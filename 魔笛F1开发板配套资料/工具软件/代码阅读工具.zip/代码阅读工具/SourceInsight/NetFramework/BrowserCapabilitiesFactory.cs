namespace System.Web.Configuration {
public class BrowserCapabilitiesFactory : BrowserCapabilitiesFactoryBase
{

	// Constructors
	public BrowserCapabilitiesFactory() {}

	// Methods
	public virtual void ConfigureBrowserCapabilities(System.Collections.Specialized.NameValueCollection headers, System.Web.HttpBrowserCapabilities browserCaps) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
