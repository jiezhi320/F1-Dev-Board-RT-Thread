namespace System.Windows.Forms.Layout {
public class ArrangedElementCollection : System.Collections.IList, System.Collections.ICollection, System.Collections.IEnumerable
{

	// Methods
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
	public virtual void CopyTo(System.Array array, int index) {}
	public virtual System.Collections.IEnumerator GetEnumerator() {}
	public Type GetType() {}
	public virtual string ToString() {}

	// Properties
	public bool IsReadOnly { get{} }
	public int Count { get{} }
}

}
