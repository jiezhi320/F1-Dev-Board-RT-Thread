namespace System.Web.Services.Description {
public class BasicProfileViolationCollection : System.Collections.CollectionBase, System.Collections.IList, System.Collections.ICollection, System.Collections.IEnumerable, IEnumerable<System.Web.Services.Description.BasicProfileViolation>
{

	// Constructors
	public BasicProfileViolationCollection() {}

	// Methods
	public void Insert(int index, BasicProfileViolation violation) {}
	public int IndexOf(BasicProfileViolation violation) {}
	public bool Contains(BasicProfileViolation violation) {}
	public void Remove(BasicProfileViolation violation) {}
	public void CopyTo(BasicProfileViolation[] array, int index) {}
	public virtual string ToString() {}
	public virtual void Clear() {}
	public virtual void RemoveAt(int index) {}
	public virtual System.Collections.IEnumerator GetEnumerator() {}
	public Type GetType() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public BasicProfileViolation Item { get{} set{} }
	public int Capacity { get{} set{} }
	public int Count { get{} }
}

}
