namespace Microsoft.JScript {
public class Binding : AST
{

	// Methods
	public static bool IsMissing(object value) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
