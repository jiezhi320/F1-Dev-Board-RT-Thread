namespace Microsoft.VisualBasic.ApplicationServices {
public class AssemblyInfo
{

	// Constructors
	public AssemblyInfo(System.Reflection.Assembly currentAssembly) {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public string Description { get{} }
	public string CompanyName { get{} }
	public string Title { get{} }
	public string Copyright { get{} }
	public string Trademark { get{} }
	public string ProductName { get{} }
	public System.Version Version { get{} }
	public string AssemblyName { get{} }
	public string DirectoryPath { get{} }
	public ReadOnlyCollection<System.Reflection.Assembly> LoadedAssemblies { get{} }
	public string StackTrace { get{} }
	public long WorkingSet { get{} }
}

}
