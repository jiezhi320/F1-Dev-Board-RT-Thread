namespace System.Configuration {
public class AppSettingsReader
{

	// Constructors
	public AppSettingsReader() {}

	// Methods
	public object GetValue(string key, Type type) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
