namespace System.DirectoryServices.Protocols {
public class BerConverter
{

	// Methods
	public static byte[] Encode(string format, object[] value) {}
	public static object[] Decode(string format, byte[] value) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
