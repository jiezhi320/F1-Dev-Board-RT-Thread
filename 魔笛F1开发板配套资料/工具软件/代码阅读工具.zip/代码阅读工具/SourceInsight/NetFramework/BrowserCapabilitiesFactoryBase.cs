namespace System.Web.Configuration {
public class BrowserCapabilitiesFactoryBase
{

	// Constructors
	public BrowserCapabilitiesFactoryBase() {}

	// Methods
	public virtual void ConfigureBrowserCapabilities(System.Collections.Specialized.NameValueCollection headers, System.Web.HttpBrowserCapabilities browserCaps) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
