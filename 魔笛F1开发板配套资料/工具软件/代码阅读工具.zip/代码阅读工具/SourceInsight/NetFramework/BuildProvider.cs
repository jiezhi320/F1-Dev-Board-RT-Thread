namespace System.Web.Compilation {
public class BuildProvider
{

	// Methods
	public virtual void GenerateCode(AssemblyBuilder assemblyBuilder) {}
	public virtual Type GetGeneratedType(System.CodeDom.Compiler.CompilerResults results) {}
	public virtual string GetCustomString(System.CodeDom.Compiler.CompilerResults results) {}
	public virtual BuildProviderResultFlags GetResultFlags(System.CodeDom.Compiler.CompilerResults results) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public CompilerType CodeCompilerType { get{} }
	public System.Collections.ICollection VirtualPathDependencies { get{} }
}

}
