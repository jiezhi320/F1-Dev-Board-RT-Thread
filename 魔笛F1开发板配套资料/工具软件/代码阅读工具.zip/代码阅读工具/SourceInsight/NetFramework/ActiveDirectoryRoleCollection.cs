namespace System.DirectoryServices.ActiveDirectory {
public class ActiveDirectoryRoleCollection : System.Collections.ReadOnlyCollectionBase, System.Collections.ICollection, System.Collections.IEnumerable
{

	// Methods
	public bool Contains(ActiveDirectoryRole role) {}
	public int IndexOf(ActiveDirectoryRole role) {}
	public void CopyTo(ActiveDirectoryRole[] roles, int index) {}
	public virtual System.Collections.IEnumerator GetEnumerator() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public ActiveDirectoryRole Item { get{} }
	public int Count { get{} }
}

}
