namespace Microsoft.JScript {
public class BitwiseBinary : BinaryOp
{

	// Constructors
	public BitwiseBinary(int operatorTok) {}

	// Methods
	public object EvaluateBitwiseBinary(object v1, object v2) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
