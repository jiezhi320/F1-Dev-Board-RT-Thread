namespace System.DirectoryServices.Protocols {
public class AsqRequestControl : DirectoryControl
{

	// Constructors
	public AsqRequestControl() {}
	public AsqRequestControl(string attributeName) {}

	// Methods
	public virtual byte[] GetValue() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public string AttributeName { get{} set{} }
	public string Type { get{} }
	public bool IsCritical { get{} set{} }
	public bool ServerSide { get{} set{} }
}

}
