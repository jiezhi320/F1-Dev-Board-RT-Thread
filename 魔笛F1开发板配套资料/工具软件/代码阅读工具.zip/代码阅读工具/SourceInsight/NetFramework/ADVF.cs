namespace System.Runtime.InteropServices.ComTypes {
public class ADVF : System.Enum, System.IComparable, System.IFormattable, System.IConvertible
{

	// Methods
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
	public virtual string ToString() {}
	public virtual string ToString(string format, System.IFormatProvider provider) {}
	public virtual int CompareTo(object target) {}
	public virtual string ToString(System.IFormatProvider provider) {}
	public virtual System.TypeCode GetTypeCode() {}
	public string ToString(string format) {}
	public Type GetType() {}

	// Fields
	public int value__;
	public ADVF ADVF_NODATA;
	public ADVF ADVF_PRIMEFIRST;
	public ADVF ADVF_ONLYONCE;
	public ADVF ADVF_DATAONSTOP;
	public ADVF ADVFCACHE_NOHANDLER;
	public ADVF ADVFCACHE_FORCEBUILTIN;
	public ADVF ADVFCACHE_ONSAVE;
}

}
