namespace System.Security.AccessControl {
public class AuthorizationRuleCollection : System.Collections.ReadOnlyCollectionBase, System.Collections.ICollection, System.Collections.IEnumerable
{

	// Methods
	public void CopyTo(AuthorizationRule[] rules, int index) {}
	public virtual System.Collections.IEnumerator GetEnumerator() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public AuthorizationRule Item { get{} }
	public int Count { get{} }
}

}
