namespace System.Runtime.Hosting {
public class ApplicationActivator
{

	// Constructors
	public ApplicationActivator() {}

	// Methods
	public virtual System.Runtime.Remoting.ObjectHandle CreateInstance(System.ActivationContext activationContext) {}
	public virtual System.Runtime.Remoting.ObjectHandle CreateInstance(System.ActivationContext activationContext, string[] activationCustomData) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
