namespace System.Threading {
public class AsyncFlowControl : System.ValueType, System.IDisposable
{

	// Methods
	public void Undo() {}
	public virtual int GetHashCode() {}
	public virtual bool Equals(object obj) {}
	public bool Equals(AsyncFlowControl obj) {}
	public static bool op_Equality(AsyncFlowControl a, AsyncFlowControl b) {}
	public static bool op_Inequality(AsyncFlowControl a, AsyncFlowControl b) {}
	public virtual string ToString() {}
	public Type GetType() {}
}

}
