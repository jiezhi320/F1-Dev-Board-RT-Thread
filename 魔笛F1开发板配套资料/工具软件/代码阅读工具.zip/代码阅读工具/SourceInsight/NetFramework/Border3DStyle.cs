namespace System.Windows.Forms {
public class Border3DStyle : System.Enum, System.IComparable, System.IFormattable, System.IConvertible
{

	// Methods
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
	public virtual string ToString() {}
	public virtual string ToString(string format, System.IFormatProvider provider) {}
	public virtual int CompareTo(object target) {}
	public virtual string ToString(System.IFormatProvider provider) {}
	public virtual System.TypeCode GetTypeCode() {}
	public string ToString(string format) {}
	public Type GetType() {}

	// Fields
	public int value__;
	public Border3DStyle Adjust;
	public Border3DStyle Bump;
	public Border3DStyle Etched;
	public Border3DStyle Flat;
	public Border3DStyle Raised;
	public Border3DStyle RaisedInner;
	public Border3DStyle RaisedOuter;
	public Border3DStyle Sunken;
	public Border3DStyle SunkenInner;
	public Border3DStyle SunkenOuter;
}

}
