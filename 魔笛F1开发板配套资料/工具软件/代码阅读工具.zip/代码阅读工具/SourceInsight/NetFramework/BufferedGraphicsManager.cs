namespace System.Drawing {
public class BufferedGraphicsManager
{

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public BufferedGraphicsContext Current { get{} }
}

}
