namespace System {
public class Buffer
{

	// Methods
	public static void BlockCopy(Array src, int srcOffset, Array dst, int dstOffset, int count) {}
	public static byte GetByte(Array array, int index) {}
	public static void SetByte(Array array, int index, byte value) {}
	public static int ByteLength(Array array) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
