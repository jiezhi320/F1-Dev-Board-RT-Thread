namespace System.Web.Configuration {
public class BrowserCapabilitiesCodeGenerator
{

	// Constructors
	public BrowserCapabilitiesCodeGenerator() {}

	// Methods
	public virtual void Create() {}
	public bool Uninstall() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
