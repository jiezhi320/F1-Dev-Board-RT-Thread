namespace Microsoft.VisualBasic.CompilerServices {
public class BooleanType
{

	// Methods
	public static bool FromString(string Value) {}
	public static bool FromObject(object Value) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
