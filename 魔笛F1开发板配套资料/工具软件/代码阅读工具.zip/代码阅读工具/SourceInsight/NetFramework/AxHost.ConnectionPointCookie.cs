namespace System.Windows.Forms {
public class ConnectionPointCookie
{

	// Constructors
	public ConnectionPointCookie(object source, object sink, Type eventInterface) {}

	// Methods
	public void Disconnect() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
